import Todo from "./component/todo"
import './App.css'
export default function App() {
  
  return<div className="App"><Todo/></div>
   
}
