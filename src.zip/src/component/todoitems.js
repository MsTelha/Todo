//import { useContext } from "react";
//import { metadata } from "./todo";
import { useSelector } from "react-redux";
export default function TodoItems(props) {
//const { removeHandler, editHandler, deleteHandler, items} = useContext(metadata);
const addTodo = useSelector((state)=>state.items)

  
//console.log(addTodo);
//console.log(items);
    return(
        <div>
          {addTodo.map((val) => {
            return (
              <div className="list" key={val.id}>
                {val.data}
                <span style={{ display: "flex" }}>
                  <button
                    className="edt-btn"
                    onClick={() => props.editHandler(val.id)}
                  >
                    Edit
                  </button>
                  <button
                    className="dlt-btn"
                    onClick={() => props.deleteHandler(val.id)}
                  >
                    Delete
                  </button>
                </span>
              </div>
            );
          })}
        <div className="footer">
          <button className="footer-btn" onClick={props.removeHandler}>
            Clear List
          </button>
        </div>
      </div>
    );
}