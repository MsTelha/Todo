//import { useEffect, useState, createContext } from "react";
//import axios from "axios";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import "./Todo.css";
import TodoItems from "./todoitems";
import Button from '@mui/material/Button';

//export const metadata = createContext("");

let editId;

function Todo() {
  const dispatch = useDispatch();
  const editTodo = useSelector((state) => state.editItems);
  const [input, setInput] = useState("");
  const addTodo = useSelector((state) => state.items);

  // const [items, setItems] = useState([]);
  // const [editItem, setEditItem] = useState(true);
  // const [editedItem, setEditedItem] = useState(null);

  ////////////////////////////////////////////////   ChangeHandler ////////////////////////////////////////////////////
  const onChange = (event) => {
    setInput(event.target.value);
    // console.log("testing");
  };

  /////////////////////////////////////////////      deleteHandler /////////////////////////////////////////////////////

  const deleteHandler = (id) => {
    dispatch({
      type: "delete-Todo",
      id: id,
    });
    // const updateditems = items.filter((val) => {
    //   return index !== val.id;
    // });
    // setItems(updateditems);
  };

  /////////////////////////////////////////////      removeHandler /////////////////////////////////////////////////////

  const removeHandler = () => {
    dispatch({
      type: "remove-Todo",
    });
    //setItems([]);
  };

  /////////////////////////////////////////////      editHandler /////////////////////////////////////////////////////

  const editHandler = (id) => {
    editId = id;
    let test = addTodo.filter((curr) => {
      return curr.id === id;
    });
    //console.log(test[0].data);
    setInput(test[0].data);
    dispatch({
      type: "update-Todo",
      payload: {
        id: id,
      },
    });
    // const editedItem = items.find((value) => {
    //   return value.id === id;
    // });
    // console.log(editedItem);
    // setEditItem(false);
    // setInput(editedItem.name);
    // setEditedItem(id);
  };

  /////////////////////////////////////////////      clickaddHandler /////////////////////////////////////////////////////
  //const dummy = [1, 2, 3, 4, 5];

  const clickHandler = () => {
    if (!input) {
      alert("plz Enter data first");
    } else if (input && !editTodo) {
      console.log("else if");
      dispatch({
        type: "add-Todo",
        payload: {
          data: input,
          id: editId,
        },
      });
      setInput("");
    } else {
      console.log("else");
      dispatch({
        type: "add-Todo",
        payload: {
          id: Math.random(),
          data: input,
        },
      });
      setInput("");
    }
    // if (!input) {
    //   //alert("plz Enter data first");
    // } else if (input && !editItem) {
    //   setItems(
    //     items.map((val) => {
    //       if (val.id === editedItem) {
    //         return { ...val, title: input };
    //       }
    //       return val;
    //     })
    //   );
    //   setEditItem(true);
    //   setInput("");
    //   setEditedItem(null);
    // } else {
    //   let itemslist = { id: new Date().getTime().toString(), title: input };
    //   setItems([...items, itemslist]);
    //   setInput("");
    // }
  };
  /////////////////////////////////////////////     getdatabyApi /////////////////////////////////////////////////////

  // useEffect(() => {
  //   axios("https://jsonplaceholder.typicode.com/posts").then((res) => {
  //     setItems(res.data);
  //   });
  // }, []);

  return (
    <div>      
      <div>
        <div className="text">Add Your Todo List Here!!</div>
        <input
          className="input"
          placeholder="Add Items In Todo List"
          value={input}
          onChange={onChange}
        ></input>
        {editTodo ? (
          <Button variant="contained" size="small" onClick={clickHandler}>Add Todo</Button>
          // <button className="button" onClick={clickHandler} >
          //   Add Todo
          // </button>
        ) : (
          <button className="button" onClick={clickHandler}>
            Edit
          </button>
        )}
      </div>
      {/* /////////////////////////////////// useContext ///////////////////////////////////////////////////// */}
      {/* <div>
        {" "}
        <metadata.Provider
          value={{
            removeHandler: { removeHandler },
            editHandler: { editHandler },
            deleteHandler: { deleteHandler },
            items: items,
            editItem: editItem,
          }}
        >
          <TodoItems />
        </metadata.Provider>
      </div> */}
      <div>
        <TodoItems
          removeHandler={removeHandler}
          editHandler={editHandler}
          deleteHandler={deleteHandler}
        />
      </div>
    </div>
  );
}
export default Todo;
